import React from "react";

export function Demo2Dashboard() {
    return <></>;
}
