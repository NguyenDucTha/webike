export {AuthPage} from "./pages/AuthPage";
export {default as Logout} from "./pages/Logout";